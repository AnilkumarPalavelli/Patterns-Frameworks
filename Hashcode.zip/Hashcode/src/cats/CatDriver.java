package cats;

public class CatDriver {

	public static void main(String[] args) {
		Cat c1 = new Cat("Kit", 2);
        Cat c2 = new Cat("Kite", 3);
        Cat c3 = new Cat("Kit", 2);
        Cat c4=c3;

        System.out.println("***** .equals *****");
        System.out.println(c1.equals(c2));//f
        System.out.println(c1.equals(c3));//t
        System.out.println(c2.equals(c3));//f
        System.out.println(c3.equals(c4));//t

        System.out.println("***** == *****");
        System.out.println((c1 == c2));//f
        System.out.println((c1 == c3));//f
        System.out.println((c2 == c3));//f
        System.out.println((c3 == c4));//t

        System.out.println("***** hashcode *****");
        System.out.println(c1.hashCode());
        System.out.println(c2.hashCode());
        System.out.println(c3.hashCode());
        
        System.out.println("*****address*****");
        System.out.println(Integer.toHexString(System.identityHashCode(c1)));
        System.out.println(Integer.toHexString(System.identityHashCode(c2)));
        System.out.println(Integer.toHexString(System.identityHashCode(c3)));

	}

}
