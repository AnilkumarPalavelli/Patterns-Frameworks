package dogs;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.ListIterator;
import java.util.Scanner;

public class LinkedListDemo {

	public static void main(String[] args) {
		LinkedList<String>mydogs=new LinkedList<String>();
		mydogs.add("puppy");
		mydogs.add("Jimmy");
		mydogs.add("Maggie");
		mydogs.add("Bantu");
		mydogs.add("John");
		mydogs.add("Rock");
		mydogs.remove(2);
		System.out.println(mydogs);
		System.out.println("*****************************");
		
		
		for(String myd: mydogs) {
			System.out.println(myd);
		}
		System.out.println("*********************************");
		
		Iterator itr=mydogs.iterator();
		while(itr.hasNext()){
			System.out.println(itr.next());
			
			
		}
		System.out.println("***************************************");
		
		ListIterator<String> iter = mydogs.listIterator();
		    while(iter.hasNext()) {
		    	System.out.println(iter.next());
		    }
		    System.out.println("************************************");
		    while(iter.hasPrevious()) {
		    	System.out.println(iter.previous());
		    	
		    }
		    System.out.println("**********************************************");
		    
		    Scanner sc=new Scanner(System.in);
		    System.out.println("Enter the number from o to size-1");
		    Integer in1=sc.nextInt();
		    for(int i=0;i<in1;i++) {
		    	System.out.println(mydogs.get(i));
		    }
		    
		    
		
		

	}

}
