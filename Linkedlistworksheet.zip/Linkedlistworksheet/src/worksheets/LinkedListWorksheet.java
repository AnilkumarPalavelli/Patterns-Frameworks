package worksheets;

import java.util.LinkedList;
import java.util.ListIterator;

public class LinkedListWorksheet
{
	private static LinkedList<Integer>myList = new LinkedList<Integer>();
	public static void main(String[] args) {
	
		//list  null
		myList.addFirst(3);
		//list  3  null
		
		myList.addFirst(2);
		//list 2 3 
		
		myList.addLast(6);
		// list 2 3  6
		
		myList.addLast(8);
		// list 2 3  6 8
		
		myList.addFirst(15);
		//list 15 2 3  6 8
		
		myList.add(3, 17);
		//list 15 2 3 17  6 8
		
		myList.add(5, 25);
		// list 15 2 3 17 6 25 8
		
		myList.add(myList.indexOf(2) + 1, 34);
		//list 15 2 34 3 17 6 25 8
		printList();
		myList.set(4, 100);
		//list 15 2 34 3 100  6 25 8
		System.out.println(myList);
		System.out.println("*************************************");
		System.out.println(myList.contains(34));
		System.out.println(myList.contains(27));
		System.out.println("******************************");
		printList();
		
		System.out.println(myList.size());
		
		System.out.println("************");
		
		myList.removeFirst();
		System.out.println(myList);
		
		System.out.println("***************************");
		myList.removeLast();
		System.out.println(myList);
		System.out.println("**********************");
		printList();
		
		myList.addFirst(45);
		myList.addFirst(30);
		myList.addLast(75);
		myList.addLast(93);
		myList.addFirst(37);
		myList.add(5, 110);
		myList.add(9, 46);
		printList();
		removeOddNumbers();
		System.out.println();
		printList();

		
		
		
		
		}
	private static void printList() {
		ListIterator<Integer> iter1 = myList.listIterator();
	    while(iter1.hasNext()) {
	    	System.out.println(iter1.next()+" ");
	    }
	    System.out.println("************************************");
	    
	    
	}
	private static void removeOddNumbers() {
		ListIterator<Integer> iter1 = myList.listIterator();
	    while(iter1.hasNext()) {
	    	if(iter1.next()%2!=0) {
	    		iter1.remove();
	    		
	    	}
	    	
	    }
		
    	
    }

}
