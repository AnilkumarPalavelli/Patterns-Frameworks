package students;

public class Student implements Comparable<Student> {
	private int idNum;
    private String lastName;
    private String firstName;
    private double gpa;
    
    public Student(int idNum, String lastName, String firstName, double gpa) {
        this.idNum = idNum;
        this.lastName = lastName;
        this.firstName = firstName;
        this.gpa = gpa;
    }
    
    

    public int getIdNum() {
        return idNum;
    }

    public String getLastName() {
        return lastName;
    }

    public String getFirstName() {
        return firstName;
    }

    public double getGpa() {
        return gpa;
    }

    public void setIdNum(int idNum) {
        this.idNum = idNum;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setGpa(double gpa) {
        this.gpa = gpa;
    }
    
    public String toString() {
        return "Student{" + "idNum=" + idNum + ", lastName=" + lastName + ", firstName=" + firstName + ", gpa=" + gpa + '}';
    }
    
    @Override
    public int compareTo(Student o) {//-ve ,0 or +ve
        //Sorting by firstName
        //return firstName.compareTo(o.getFirstName());
        return Integer.compare(this.idNum,o.getIdNum());
        //return Double.compare(this.gpa, o.getGpa());
    }

}
