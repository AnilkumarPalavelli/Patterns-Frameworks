package students;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;

public class StudentDriver {
	public static void main(String[] args) throws FileNotFoundException {
        // TODO code application logic here
        ArrayList<Student> stulist = new ArrayList<Student>();
        Scanner sc = new Scanner(new File("StudentData.txt"));

        while (sc.hasNext()) {
            Student s;
            s = new Student(sc.nextInt(), sc.next(), sc.next(), sc.nextDouble());
            stulist.add(s);
        }
        System.out.println("Printing Students after reading the data");
        printList(stulist);

        System.out.println("                                        ");
        System.out.println("Printing Students After sorting based on IdNum");
        Collections.sort(stulist);
        printList(stulist);

        System.out.println("Overriding the natural order sorting");
        //overriding the natural order sorting
        Collections.sort(stulist, new Comparator<Student>() {
            @Override
            public int compare(Student s1, Student s2) {
                if (s1.getLastName().compareTo(s2.getLastName()) == 0) {
                    return s1.getFirstName().compareTo(s2.getFirstName());
                } else {
                    return s1.getLastName().compareTo(s2.getLastName());
                }
            }

        });
        printList(stulist);
        
        System.out.println("Overring natural order wsorting using seperate class");
        Collections.sort(stulist,new StudentComparator());
        printList(stulist);
        
        Integer x = 10;
        Integer y = 20;
        System.out.println(x.compareTo(y));//-1
        System.out.println(x.compareTo(x));//0
        System.out.println(y.compareTo(x));//1
    }

    private static void printList(ArrayList<Student> sList) {
        for (Student s : sList) {
            System.out.println(s);
        }
    }
}
