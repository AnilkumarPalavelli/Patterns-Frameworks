package dogs;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

import javax.print.event.PrintJobAttributeListener;

public class DogDriver {

	public static void main(String[] args) throws FileNotFoundException {
		ArrayList<Dog>doglist=new ArrayList<Dog>();
		Scanner sc=new Scanner(new File("Dogdata.txt"));
		
		while(sc.hasNext()) {
			Dog d=new Dog(sc.next(),sc.nextInt(),sc.nextDouble());
			doglist.add(d);
		}
		
		Collections.sort(doglist);
		printList(doglist);
		
		for(Dog d:doglist) {
			System.out.println(d);
		}
		

	}

	private static void printList(ArrayList<Dog> doglist) {
		// TODO Auto-generated method stub
		
	}

}
